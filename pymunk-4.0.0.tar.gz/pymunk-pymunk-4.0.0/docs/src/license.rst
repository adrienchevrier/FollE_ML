=======
License
=======

.. include:: ../../LICENSE.txt