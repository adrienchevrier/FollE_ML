"""Very simple showcase of how to run pymunk with debug mode off
"""

import pymunkoptions
pymunkoptions.options["debug"] = False
import pymunk